from .dataset import (
    Dataset,
    small_datasets,
    intermediate_datasets,
    all_datasets,
    csv_results,
)

__version__ = "1.1.0"

